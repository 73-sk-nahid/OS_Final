#!/bin/bash

findLRU() {
    local time=("$@")
    local minimum=${time[0]}
    local pos=0

    for ((i=1; i<$#; ++i))
    do
        if [[ ${time[$i]} -lt $minimum ]]
        then
            minimum=${time[$i]}
            pos=$i
        fi
    done

    echo $pos
}

read -p "Enter number of frames: " no_of_frames
read -p "Enter number of pages: " no_of_pages
echo -n "Enter reference string: "
read -a pages

for ((i=0; i<no_of_frames; ++i))
do
    frames[$i]=-1
done

counter=0
faults=0

for ((i=0; i<no_of_pages; ++i))
do
    flag1=0
    flag2=0

    for ((j=0; j<no_of_frames; ++j))
    do
        if [[ ${frames[$j]} -eq ${pages[$i]} ]]
        then
            counter=$((counter+1))
            time[$j]=$counter
            flag1=1
            flag2=1
            break
        fi
    done

    if [[ $flag1 -eq 0 ]]
    then
        for ((j=0; j<no_of_frames; ++j))
        do
            if [[ ${frames[$j]} -eq -1 ]]
            then
                counter=$((counter+1))
                faults=$((faults+1))
                frames[$j]=${pages[$i]}
                time[$j]=$counter
                flag2=1
                break
            fi
        done
    fi

    if [[ $flag2 -eq 0 ]]
    then
        pos=$(findLRU "${time[@]}")
        counter=$((counter+1))
        faults=$((faults+1))
        frames[$pos]=${pages[$i]}
        time[$pos]=$counter
    fi

    echo

    for ((j=0; j<no_of_frames; ++j))
    do
        echo -ne "${frames[$j]}\t"
    done
done

echo -e "\n\nTotal Page Faults = $faults"
