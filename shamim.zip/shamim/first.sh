#!/bin/bash

declare -a frag b f bf ff
nb=0
nf=0

echo -e "\tMemory Management Scheme - First Fit"
echo "Enter the number of blocks:"
read nb

echo "Enter the number of files:"
read nf

echo -e "\nEnter the size of the blocks:-"
for ((i=1; i<=nb; i++))
do
    echo -n "Block $i:"
    read b[$i]
done

echo -e "Enter the size of the files:-"
for ((i=1; i<=nf; i++))
do
    echo -n "File $i:"
    read f[$i]
done

for ((i=1; i<=nf; i++))
do
    for ((j=1; j<=nb; j++))
    do
        if [[ ${bf[$j]} -ne 1 ]]
        then
            temp=$((b[$j] - f[$i]))
            if [[ $temp -ge 0 ]]
            then
                ff[$i]=$j
                frag[$i]=$temp
                bf[${ff[$i]}]=1
                break
            fi
        fi
    done
done

echo -e "\nFile_no:\tFile_size:\tBlock_no:\tBlock_size:\tFragment"
for ((i=1; i<=nf; i++))
do
    echo -e "$i\t\t${f[$i]}\t\t${ff[$i]}\t\t${b[${ff[$i]}]}\t\t${frag[$i]}"
done
