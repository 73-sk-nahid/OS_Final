#!/bin/bash

print() {
    local frameno=$1
    local frame=("$@")
    for ((j=0; j<$frameno; ++j))
    do
        echo -ne "${frame[$j]}\t"
    done
    echo
}

read -p "Enter the number of pages: " n
echo -n "Enter the page reference numbers: "
read -a page
read -p "Enter the number of frames: " frameno

for ((i=0; i<frameno; ++i))
do
    frame[$i]=-1
done

count=0
move=0
declare -a count1

echo -e "Page reference string\tFrames"

for ((i=0; i<n; ++i))
do
    echo -ne "${page[$i]}\t\t\t"
    flag=0

    for ((j=0; j<frameno; ++j))
    do
        if [[ ${page[$i]} -eq ${frame[$j]} ]]
        then
            flag=1
            count1[$j]=$((count1[$j]+1))
            echo "No replacement"
            break
        fi
    done

    if [[ $flag -eq 0 && $count -lt $frameno ]]
    then
        frame[$move]=${page[$i]}
        count1[$move]=1
        move=$(( (move+1) % frameno ))
        count=$((count+1))
        print $frameno "${frame[@]}"
    elif [[ $flag -eq 0 ]]
    then
        repindex=0
        leastcount=${count1[0]}

        for ((j=1; j<frameno; ++j))
        do
            if [[ ${count1[$j]} -lt $leastcount ]]
            then
                repindex=$j
                leastcount=${count1[$j]}
            fi
        done

        frame[$repindex]=${page[$i]}
        count1[$repindex]=1
        count=$((count+1))
        print $frameno "${frame[@]}"
    fi
done

rate=$(bc <<< "scale=2; $count / $n")
echo -e "\nNumber of page faults is $count"
echo "Fault rate is $rate"
